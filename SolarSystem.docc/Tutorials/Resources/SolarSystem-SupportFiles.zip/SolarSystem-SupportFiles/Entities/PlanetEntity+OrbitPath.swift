//
//  PlanetEntity+OrbitPath.swift
//  SolarSystem
//
//  궤도선으로 쓰는 고리 메시를 만드는 코드입니다. 튜토리얼 1챕터에서
//  `Self.configureOrbitPath(...)`로 부르기만 하고, 메시를 직접 쌓는
//  부분은 본문의 주제가 아니라 이 파일로 빼 두었습니다.
//

import RealityKit
import UIKit

extension PlanetEntity {
    /// Builds the thin, static ring that traces this planet's orbit around
    /// the Sun, so the path itself is visible, not just implied by the
    /// planet's motion.
    static func configureOrbitPath(_ path: Entity, orbitRadius: Float) {
        let thickness: Float = 0.012
        guard let mesh = try? makeRingMesh(
            innerRadius: max(orbitRadius - thickness, 0),
            outerRadius: orbitRadius,
            segments: 96
        ) else { return }

        let material = UnlitMaterial(color: UIColor(white: 0.75, alpha: 1))
        let visual = ModelEntity(mesh: mesh, materials: [material])
        path.addChild(visual)

        // The ring mesh faces +Z by default; lay it flat into the orbital
        // (XZ) plane it's meant to trace.
        path.orientation = .init(angle: -.pi / 2, axis: [1, 0, 0])
    }

    /// Builds a flat, ring-shaped (annulus) mesh facing +Z, since RealityKit
    /// has no built-in torus/ring generator.
    static func makeRingMesh(innerRadius: Float, outerRadius: Float, segments: Int = 48) throws -> MeshResource {
        var positions: [SIMD3<Float>] = []
        var normals: [SIMD3<Float>] = []
        var uvs: [SIMD2<Float>] = []

        for i in 0...segments {
            let angle = Float(i) / Float(segments) * 2.0 * .pi
            let x = cos(angle)
            let y = sin(angle)
            positions.append([x * outerRadius, y * outerRadius, 0])
            positions.append([x * innerRadius, y * innerRadius, 0])
            normals.append([0, 0, 1])
            normals.append([0, 0, 1])
            let u = Float(i) / Float(segments)
            uvs.append([u, 0])
            uvs.append([u, 1])
        }

        var indices: [UInt32] = []
        for i in 0..<segments {
            let outerA = UInt32(i * 2)
            let innerA = UInt32(i * 2 + 1)
            let outerB = UInt32((i + 1) * 2)
            let innerB = UInt32((i + 1) * 2 + 1)
            // Front face.
            indices.append(contentsOf: [outerA, innerA, outerB])
            indices.append(contentsOf: [innerA, innerB, outerB])
            // Back face, so the ring reads from both sides.
            indices.append(contentsOf: [outerB, innerA, outerA])
            indices.append(contentsOf: [outerB, innerB, innerA])
        }

        var descriptor = MeshDescriptor(name: "selectionRing")
        descriptor.positions = MeshBuffers.Positions(positions)
        descriptor.normals = MeshBuffers.Normals(normals)
        descriptor.textureCoordinates = MeshBuffers.TextureCoordinates(uvs)
        descriptor.primitives = .triangles(indices)

        return try MeshResource.generate(from: [descriptor])
    }
}
