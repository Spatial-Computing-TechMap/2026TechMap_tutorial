SolarSystem 튜토리얼 · 함께 쓰는 파일
=====================================

이 폴더의 .swift 파일들은 튜토리얼에서 한 줄씩 따라 쓰지 않고 그대로 받아
쓰는 코드입니다. 새로 만든 visionOS 프로젝트의 같은 이름 폴더에 그대로
끌어다 놓으세요.

왜 따라 쓰지 않나요?
- 설정값과 문구만 들어 있어 새로 배울 개념이 없거나,
- Apple의 Hello World 샘플에서 그대로 가져온 지구 전용 코드이거나,
- 이 앱의 주제(행성을 보고 집어서 불러오기)와 거리가 먼 코드입니다.

튜토리얼에서 직접 작성하는 파일
-------------------------------
  Systems/RotationSystem.swift              1챕터
  Entities/PlanetEntity.swift               1~2챕터
  Entities/PlanetSelectionComponent.swift   2챕터
  RealityViews/Planet.swift                 2챕터
  RealityViews/FocusStage.swift             2챕터
  Solar System/SwitchWindows.swift          2챕터
  Solar System/SolarCard.swift              2챕터
  Model/AppModel.swift                      2~3챕터
  Solar System/SolarSystem.swift            3챕터
  Solar System/ToggleImmersiveSpaceButton.swift  3챕터
  SolarSystemApp.swift                      3챕터

이 폴더에 들어 있는 파일
------------------------
  Model/PlanetID.swift                           행성 여덟 개의 식별자와 표시 이름, 설명 문구
  Model/Module.swift                             소개 카드에 쓰는 문구 모음
  Model/HeadTracker.swift                        ARKit으로 머리 위치를 읽는 도우미
  Entities/PlanetEntity+Configuration.swift      여덟 행성의 크기·궤도·속도 설정값
  Entities/EarthEntity.swift                     지구 전용 엔티티 (Apple Hello World 샘플 기반)
  Entities/EarthEntity+Configuration.swift       지구 설정값
  Entities/SatelliteEntity.swift                 달과 인공위성 엔티티
  Entities/SatelliteEntity+Configuration.swift   달·위성 설정값
  Entities/Entity+Trace.swift                    궤적 그리기 확장
  Entities/Entity+Sunlight.swift                 이미지 기반 조명(IBL) 확장
  Systems/TraceSystem.swift                      궤적을 매 프레임 갱신하는 시스템
  RealityViews/Starfield.swift                   별 배경 (거대한 구를 뒤집어 안쪽에 텍스처)
  RealityViews/Sun.swift                         태양 모델과 점광원
  Solar System/PlanetInfoPanel.swift             확대된 행성 옆에 뜨는 설명 패널
  Solar System/SolarSystemControls.swift         창 안의 컨트롤 UI
  Solar System/SolarSystemModule.swift           모듈 미리보기 뷰
  Entities/PlanetEntity+OrbitPath.swift          궤도선 고리 메시 생성

별 배경 이미지와 행성 모델 패키지(SolarSystemAssets)는 별도의
SolarSystem-Assets.zip으로 제공됩니다.
